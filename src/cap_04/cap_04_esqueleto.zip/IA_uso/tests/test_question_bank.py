import json
from pathlib import Path


def test_seed_file_has_minimum_schema():
    seed_path = Path("data/questions_seed.json")
    payload = json.loads(seed_path.read_text(encoding="utf-8"))

    assert isinstance(payload, list)
    assert len(payload) >= 1
    first = payload[0]
    assert {"code", "statement", "options", "correct_option"}.issubset(first.keys())

