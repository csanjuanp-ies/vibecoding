from types import SimpleNamespace

from app.services.grading_service import GradingService


def test_grade_summary():
    answers = [
        SimpleNamespace(selected_option="A", question=SimpleNamespace(correct_option="A")),
        SimpleNamespace(selected_option="B", question=SimpleNamespace(correct_option="A")),
        SimpleNamespace(selected_option=None, question=SimpleNamespace(correct_option="C")),
    ]

    result = GradingService.grade(answers)

    assert result["total"] == 3
    assert result["correct"] == 1
    assert result["wrong"] == 2
    assert result["percentage"] == 33.33

