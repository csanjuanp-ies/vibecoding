from app.services.exam_navigation_service import ExamNavigationService


def test_progress_payload_values():
    progress = ExamNavigationService.progress(4, 35)

    assert progress["current"] == 5
    assert progress["total"] == 35
    assert progress["percent"] > 0

