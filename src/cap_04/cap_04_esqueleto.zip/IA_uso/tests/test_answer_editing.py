class DummyAnswer:
    def __init__(self, selected_option):
        self.selected_option = selected_option


from app.services.exam_navigation_service import ExamNavigationService


def test_unanswered_count():
    answers = [DummyAnswer("A"), DummyAnswer(None), DummyAnswer(""), DummyAnswer("C")]
    pending = ExamNavigationService.unanswered_count(answers)

    assert pending == 2

