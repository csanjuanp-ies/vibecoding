import pytest

from app.utils.randomizer import pick_unique


def test_pick_unique_without_repetition():
    items = list(range(50))
    picked = pick_unique(items, 35)

    assert len(picked) == 35
    assert len(set(picked)) == 35


def test_pick_unique_raises_with_insufficient_items():
    with pytest.raises(ValueError):
        pick_unique([1, 2], 3)

