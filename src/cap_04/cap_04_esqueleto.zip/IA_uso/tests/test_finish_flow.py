def test_finish_route_exists(client):
    response = client.get("/exam/finish")

    assert response.status_code == 200
    assert b"Finalizar Examen" in response.data

