class GradingService:
    @staticmethod
    def grade(answers):
        total = len(answers)
        correct = 0
        for answer in answers:
            if answer.selected_option and answer.selected_option == answer.question.correct_option:
                correct += 1

        wrong = total - correct
        percentage = round((correct / total) * 100, 2) if total else 0
        return {
            "total": total,
            "correct": correct,
            "wrong": wrong,
            "percentage": percentage,
        }

