from app.extensions import db
from app.models.answer import Answer


class AnswerService:
    @staticmethod
    def save_answer(exam_session_id, question_id, selected_option):
        answer = Answer.query.filter_by(
            exam_session_id=exam_session_id,
            question_id=question_id,
        ).first()

        if answer is None:
            answer = Answer(
                exam_session_id=exam_session_id,
                question_id=question_id,
            )
            db.session.add(answer)

        answer.selected_option = selected_option
        db.session.commit()
        return answer

