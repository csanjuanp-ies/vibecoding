class ExamNavigationService:
    @staticmethod
    def progress(current_index, total_questions):
        return {
            "current": current_index + 1,
            "total": total_questions,
            "percent": round(((current_index + 1) / total_questions) * 100, 2),
        }

    @staticmethod
    def unanswered_count(answers):
        return sum(1 for answer in answers if not answer.selected_option)

