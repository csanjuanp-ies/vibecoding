import random

from app.models.question import Question


class ExamGeneratorService:
    @staticmethod
    def generate_exam_questions(total_questions=35):
        questions = Question.query.all()
        if len(questions) < total_questions:
            raise ValueError("No hay suficientes preguntas para generar el examen")
        return random.sample(questions, total_questions)

