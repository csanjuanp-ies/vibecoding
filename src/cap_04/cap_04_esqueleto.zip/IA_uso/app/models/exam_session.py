from datetime import datetime

from app.extensions import db


class ExamSession(db.Model):
    __tablename__ = "exam_sessions"

    id = db.Column(db.Integer, primary_key=True)
    status = db.Column(db.String(20), default="in_progress", nullable=False)
    total_questions = db.Column(db.Integer, default=35, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    finished_at = db.Column(db.DateTime, nullable=True)

    answers = db.relationship("Answer", back_populates="exam_session", cascade="all, delete-orphan")

