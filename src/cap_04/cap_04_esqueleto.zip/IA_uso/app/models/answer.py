from app.extensions import db


class Answer(db.Model):
    __tablename__ = "answers"

    id = db.Column(db.Integer, primary_key=True)
    exam_session_id = db.Column(db.Integer, db.ForeignKey("exam_sessions.id"), nullable=False)
    question_id = db.Column(db.Integer, db.ForeignKey("questions.id"), nullable=False)
    selected_option = db.Column(db.String(1), nullable=True)

    exam_session = db.relationship("ExamSession", back_populates="answers")
    question = db.relationship("Question")

    __table_args__ = (
        db.UniqueConstraint("exam_session_id", "question_id", name="uq_answer_per_question"),
    )

