from dataclasses import dataclass


@dataclass
class ExamSummarySchema:
    total: int
    correct: int
    wrong: int
    percentage: float

