from flask import Blueprint

exam_bp = Blueprint("exam", __name__)

from app.blueprints.exam import routes  # noqa: E402,F401

