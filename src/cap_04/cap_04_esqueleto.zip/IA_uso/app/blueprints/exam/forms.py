from dataclasses import dataclass


@dataclass
class AnswerForm:
    selected_option: str | None = None

