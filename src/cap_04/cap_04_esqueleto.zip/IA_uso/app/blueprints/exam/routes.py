from flask import render_template

from app.blueprints.exam import exam_bp


@exam_bp.route("/")
def start_exam():
    return render_template("exam/start.html")


@exam_bp.route("/exam/question/<int:index>")
def show_question(index):
    return render_template("exam/question.html", index=index)


@exam_bp.route("/exam/review")
def review_exam():
    return render_template("exam/review.html")


@exam_bp.route("/exam/finish")
def finish_exam():
    return render_template("exam/confirm_finish.html")


@exam_bp.route("/exam/result")
def exam_result():
    return render_template("exam/result.html")

