import random


def pick_unique(items, count):
    if len(items) < count:
        raise ValueError("No hay elementos suficientes")
    return random.sample(items, count)

