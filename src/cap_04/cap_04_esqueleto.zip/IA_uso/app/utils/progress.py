def calculate_progress(current_index, total):
    current = current_index + 1
    percentage = round((current / total) * 100, 2) if total else 0
    return {"current": current, "total": total, "percentage": percentage}

