document.addEventListener('DOMContentLoaded', function () {
  // Placeholder para futuras mejoras de navegacion de examen.
});

