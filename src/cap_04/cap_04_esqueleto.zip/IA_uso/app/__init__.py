from flask import Flask

from app.blueprints.exam import exam_bp
from app.config import Config
from app.extensions import db, migrate


def create_app(config_object=Config):
    app = Flask(__name__)
    app.config.from_object(config_object)

    db.init_app(app)
    migrate.init_app(app, db)

    app.register_blueprint(exam_bp)

    with app.app_context():
        db.create_all()

    return app

