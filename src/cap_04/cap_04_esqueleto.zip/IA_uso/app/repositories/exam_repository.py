from app.extensions import db
from app.models.exam_session import ExamSession


class ExamRepository:
    @staticmethod
    def create_session(total_questions=35):
        session = ExamSession(total_questions=total_questions)
        db.session.add(session)
        db.session.commit()
        return session

    @staticmethod
    def get_session(session_id):
        return ExamSession.query.get(session_id)

