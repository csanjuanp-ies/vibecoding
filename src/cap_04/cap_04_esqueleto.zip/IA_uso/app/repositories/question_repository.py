from app.models.question import Question


class QuestionRepository:
    @staticmethod
    def all_questions():
        return Question.query.all()

    @staticmethod
    def count_questions():
        return Question.query.count()

