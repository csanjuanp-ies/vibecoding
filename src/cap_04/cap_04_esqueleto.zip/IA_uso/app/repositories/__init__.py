from app.repositories.exam_repository import ExamRepository
from app.repositories.question_repository import QuestionRepository

__all__ = ["ExamRepository", "QuestionRepository"]

