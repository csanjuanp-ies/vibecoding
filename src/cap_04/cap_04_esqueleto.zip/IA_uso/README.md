# Aplicacion de Examenes con Flask

Proyecto base para iniciar una aplicacion Flask que gestiona un banco de preguntas, genera examenes y muestra resultados.

## Requisitos

- Python 3.10+

## Inicio rapido

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python wsgi.py
```

La app quedara disponible en `http://127.0.0.1:5000`.

## Ejecutar pruebas

```powershell
pytest -q
```

## Estructura

- `app/`: codigo principal Flask
- `data/`: datos semilla
- `tests/`: pruebas minimas

