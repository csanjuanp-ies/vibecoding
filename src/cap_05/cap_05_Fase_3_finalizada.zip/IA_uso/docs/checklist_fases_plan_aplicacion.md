# Checklist de fases del plan de aplicacion

Checklist operativo basado en el plan sugerido en `estructura_y_plan_flask.md`.

## Fase 1 - Base tecnica

- [ ] Crear `app factory` en `app/__init__.py`.
- [ ] Configurar extensiones en `app/extensions.py`:
  - [ ] `SQLAlchemy`
  - [ ] `Flask-Migrate`
  - [ ] `Flask-WTF`
- [ ] Definir modelos iniciales:
  - [ ] `Question` en `app/models/question.py`
  - [ ] `ExamSession` en `app/models/exam_session.py`
  - [ ] `Answer` en `app/models/answer.py`

## Fase 2 - Banco de preguntas (RF-01)

- [ ] Implementar carga inicial desde `data/questions_seed.json`.
- [ ] Agregar CRUD basico del banco de preguntas (interno/admin).
- [ ] Validar unicidad de identificador de pregunta.
- [ ] Validar formato de opciones/respuestas.

## Fase 3 - Flujo de examen (RF-02, RF-03, RF-04, RF-05)

- [ ] Generar sesion con 35 preguntas aleatorias sin repeticion.
- [ ] Mostrar una pregunta por vista con indicador de progreso (`n/35`).
- [ ] Guardar respuesta seleccionada por el usuario.
- [ ] Permitir editar respuestas ya registradas.
- [ ] Implementar navegacion completa:
  - [ ] Avanzar
  - [ ] Retroceder
  - [ ] Saltar a una pregunta
  - [ ] Visualizar estado de respondidas/no respondidas

## Fase 4 - Cierre y evaluacion (RF-06, RF-07, RF-08)

- [ ] Crear pantalla de confirmacion final con conteo de no respondidas.
- [ ] Bloquear cambios tras confirmar envio.
- [ ] Calcular resultado automatico:
  - [ ] Aciertos
  - [ ] Errores
  - [ ] Porcentaje
- [ ] Mostrar resumen final y detalle opcional por pregunta.

## Fase 5 - Calidad

- [ ] Crear tests unitarios de servicios:
  - [ ] Generacion (`exam_generator_service`)
  - [ ] Calificacion (`grading_service`)
  - [ ] Navegacion (`exam_navigation_service`)
- [ ] Crear tests de integracion de rutas principales.
- [ ] Cubrir casos borde:
  - [ ] Menos de 35 preguntas disponibles
  - [ ] Sesion invalida
  - [ ] Doble envio/finalizacion repetida

## Seguimiento global

- [ ] Fase 1 completada
- [ ] Fase 2 completada
- [ ] Fase 3 completada
- [ ] Fase 4 completada
- [ ] Fase 5 completada

