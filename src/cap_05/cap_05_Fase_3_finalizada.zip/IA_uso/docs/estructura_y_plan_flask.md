# Estructura recomendada para aplicacion Flask

## Checklist

- [x] Definir una estructura de proyecto escalable para Flask.
- [x] Mapear cada requisito funcional (RF-01 a RF-08) a modulos concretos.
- [x] Proponer nombres de archivos claros y mantenibles.
- [x] Entregar un plan de aplicacion por fases (MVP -> mejoras).
- [x] Incluir recomendaciones páacticas de pruebas y evolucion.

## Estructura recomendada (Flask + Blueprints + servicios)

```text
IA_uso/
|-- app/
|   |-- __init__.py
|   |-- config.py
|   |-- extensions.py
|   |-- models/
|   |   |-- __init__.py
|   |   |-- question.py
|   |   |-- exam_session.py
|   |   `-- answer.py
|   |-- repositories/
|   |   |-- __init__.py
|   |   |-- question_repository.py
|   |   `-- exam_repository.py
|   |-- services/
|   |   |-- __init__.py
|   |   |-- question_bank_service.py
|   |   |-- exam_generator_service.py
|   |   |-- exam_navigation_service.py
|   |   |-- answer_service.py
|   |   `-- grading_service.py
|   |-- blueprints/
|   |   |-- __init__.py
|   |   `-- exam/
|   |       |-- __init__.py
|   |       |-- routes.py
|   |       |-- forms.py
|   |       `-- schemas.py
|   |-- templates/
|   |   |-- base.html
|   |   `-- exam/
|   |       |-- start.html
|   |       |-- question.html
|   |       |-- review.html
|   |       |-- confirm_finish.html
|   |       `-- result.html
|   |-- static/
|   |   |-- css/
|   |   |   `-- exam.css
|   |   `-- js/
|   |       `-- exam_navigation.js
|   `-- utils/
|       |-- __init__.py
|       |-- randomizer.py
|       `-- progress.py
|-- data/
|   `-- questions_seed.json
|-- migrations/
|-- tests/
|   |-- conftest.py
|   |-- test_question_bank.py
|   |-- test_exam_generation.py
|   |-- test_navigation.py
|   |-- test_answer_editing.py
|   |-- test_finish_flow.py
|   `-- test_grading.py
|-- requirements.txt
|-- README.md
|-- wsgi.py
`-- .env.example
```

## Por qué esta estructura funciona bien

- Separa responsabilidades: `models` (datos), `repositories` (acceso), `services` (logica), `routes` (HTTP/UI).
- Facilita pruebas por capas (unitarias y de integracion).
- Evita que `routes.py` crezca como modulo monolitico.
- Escala facil si luego agregas autenticacion, API REST o panel admin.

## Mapa RF -> archivos clave

- `RF-01` Banco de preguntas: `models/question.py`, `repositories/question_repository.py`, `services/question_bank_service.py`, `data/questions_seed.json`.
- `RF-02` Generacion de 35 sin repeticion: `services/exam_generator_service.py`, `utils/randomizer.py`.
- `RF-03` Pregunta por pantalla + progreso: `blueprints/exam/routes.py`, `templates/exam/question.html`, `utils/progress.py`.
- `RF-04` Registro/modificacion respuestas: `models/answer.py`, `services/answer_service.py`, `templates/exam/question.html`.
- `RF-05` Navegacion avance/retroceso/salto/estado: `services/exam_navigation_service.py`, `templates/exam/review.html`, `static/js/exam_navigation.js`.
- `RF-06` Finalizacion controlada + confirmacion: `templates/exam/confirm_finish.html`, `blueprints/exam/routes.py`, `services/exam_navigation_service.py`.
- `RF-07` Calificacion automatica: `services/grading_service.py`, `models/exam_session.py`.
- `RF-08` Presentacion de resultados: `templates/exam/result.html`, `blueprints/exam/routes.py`.

## Plan de aplicacion sugerido

### Fase 1 - Base tecnica

- Crear `app factory` en `app/__init__.py`.
- Configurar `SQLAlchemy`, `Flask-Migrate`, `Flask-WTF` en `app/extensions.py`.
- Definir modelos iniciales: `Question`, `ExamSession`, `Answer`.

### Fase 2 - Banco de preguntas (RF-01)

- Implementar carga inicial desde `data/questions_seed.json`.
- Agregar CRUD basico del banco (aunque sea interno/admin al inicio).
- Validar unicidad de identificador y formato de opciones.

### Fase 3 - Flujo de examen (RF-02, RF-03, RF-04, RF-05)

- Generar sesion con 35 preguntas aleatorias sin repeticion.
- Mostrar una pregunta por vista con indicador `n/35`.
- Guardar respuesta seleccionada y permitir editarla.
- Implementar navegacion completa (adelante/atras/saltar/estado).

### Fase 4 - Cierre y evaluacion (RF-06, RF-07, RF-08)

- Pantalla de confirmacion final con conteo de no respondidas.
- Bloquear cambios al confirmar envio.
- Calcular aciertos, errores y porcentaje.
- Mostrar resumen y detalle opcional por pregunta.

### Fase 5 - Calidad

- Tests unitarios de servicios (`generation`, `grading`, `navigation`).
- Tests de integracion de rutas principales.
- Manejo de casos borde (menos de 35 preguntas, sesion inválida, doble envío).

## Convenciones de nombres recomendadas

- Archivos Python en `snake_case`: `grading_service.py`.
- Clases en `PascalCase`: `ExamSession`.
- Plantillas por caso de uso: `question.html`, `review.html`, `result.html`.
- Servicios terminados en `_service.py` y repositorios en `_repository.py`.

