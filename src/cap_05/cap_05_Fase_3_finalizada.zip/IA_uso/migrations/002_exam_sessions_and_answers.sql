-- Migration: Create exam_sessions and answers tables
-- Description: Create tables for managing exam sessions and user answers
-- Created: 2026-06-11
DROP TABLE IF EXISTS answers;
DROP TABLE IF EXISTS exam_sessions;

-- Create exam_sessions table
CREATE TABLE IF NOT EXISTS exam_sessions (
    id INTEGER NOT NULL,
    status VARCHAR(20) NOT NULL,
    total_questions INTEGER NOT NULL,
    created_at DATETIME NOT NULL,
    finished_at DATETIME,
    PRIMARY KEY (id)
);

-- Create answers table
CREATE TABLE IF NOT EXISTS answers (
    id INTEGER NOT NULL,
    exam_session_id INTEGER NOT NULL,
    question_id VARCHAR(50) NOT NULL,
    selected_option VARCHAR(1),
    PRIMARY KEY (id),
    CONSTRAINT uq_answer_per_question UNIQUE (exam_session_id, question_id),
    FOREIGN KEY(exam_session_id) REFERENCES exam_sessions (id),
    FOREIGN KEY(question_id) REFERENCES questions (id)
);

-- Create indices for better query performance
CREATE INDEX IF NOT EXISTS idx_answers_exam_session_id ON answers(exam_session_id);
CREATE INDEX IF NOT EXISTS idx_answers_question_id ON answers(question_id);
CREATE INDEX IF NOT EXISTS idx_exam_sessions_status ON exam_sessions(status);

