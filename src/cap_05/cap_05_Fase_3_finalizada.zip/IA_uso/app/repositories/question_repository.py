from app.models.question import Question
from app.utils.randomizer import pick_unique


class QuestionRepository:
    @staticmethod
    def all_questions():
        return Question.query.all()

    @staticmethod
    def count_questions():
        return Question.query.count()

    @staticmethod
    def first_n_questions(limit):
        # TODO DT: Puede que este no sea el mejor método para producción
        question_codes = [row.code for row in Question.query.with_entities(Question.code).all()]
        return pick_unique(question_codes, limit)

