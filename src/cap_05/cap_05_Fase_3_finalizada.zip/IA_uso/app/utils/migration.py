"""
Utilidades de migración de base de datos.

Proporciona la lógica de migración inicial SQL que se ejecuta
al arranque de la aplicación si la BD aún no está inicializada.
"""
from pathlib import Path

from sqlalchemy import inspect

from app.extensions import db


INITIAL_MIGRATION_FILE = "001_initial_from_instance.sql"
EXAM_SESSIONS_MIGRATION_FILE = "002_exam_sessions_and_answers.sql"


def run_initial_sql_migration_if_needed(app):
    """Ejecuta las migraciones SQL iniciales solo si las tablas necesarias no existen.

    Ejecuta primero la migración inicial (001_initial_from_instance.sql) si la tabla
    'questions' no existe, y luego ejecuta la migración de sesiones de examen
    (002_exam_sessions_and_answers.sql) si las tablas 'exam_sessions' o 'answers'
    no existen.

    Args:
        app: Instancia Flask con contexto de aplicación activo.

    Raises:
        FileNotFoundError: Si algún fichero SQL de migración no se encuentra.
    """
    migrations_dir = Path(app.root_path).parent / "migrations"

    # Ejecutar migración inicial si es necesaria
    if not inspect(db.engine).has_table("questions"):
        initial_migration_path = migrations_dir / INITIAL_MIGRATION_FILE

        if not initial_migration_path.exists():
            raise FileNotFoundError(
                f"No se encontro la migracion inicial: {initial_migration_path}"
            )

        migration_sql = initial_migration_path.read_text(encoding="utf-8")

        with db.engine.begin() as connection:
            raw_connection = connection.connection
            raw_connection.executescript(migration_sql)

        # Ejecutar migración de exam_sessions y answers siempre
        exam_migration_path = migrations_dir / EXAM_SESSIONS_MIGRATION_FILE

        if not exam_migration_path.exists():
            raise FileNotFoundError(
                f"No se encontro la migracion de sesiones de examen: {exam_migration_path}"
            )

        migration_sql = exam_migration_path.read_text(encoding="utf-8")

        with db.engine.begin() as connection:
            raw_connection = connection.connection
            raw_connection.executescript(migration_sql)
