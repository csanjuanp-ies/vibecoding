from flask import redirect, render_template, request, url_for

from app.blueprints.exam import exam_bp
from app.services.answer_service import AnswerService
from app.services.exam_navigation_service import ExamNavigationService
from app.services.session_service import SessionService


@exam_bp.route("/")
def start_exam():
    current_session = SessionService.get_active_session()
    questions = SessionService.get_session_question_codes(current_session.id)

    return render_template(
        "exam/start.html",
        questions=questions,
        len_questions=len(questions),
        current_session=current_session,
    )


@exam_bp.route("/exam/question/<int:index>", methods=["GET", "POST"])
def show_question(index):
    current_session = SessionService.get_active_session()
    total_questions = current_session.total_questions
    answer = SessionService.get_answer_by_index(current_session.id, index)

    if answer is None:
        return redirect(url_for("exam.review_exam"))

    if request.method == "POST":
        selected_option = request.form.get("selected_option")
        action = request.form.get("action", "next")
        navigation_actions = {"prev", "next", "finish"}

        # Solo persistimos cambios al navegar y cuando la opción enviada es válida.
        if action in navigation_actions and selected_option in {"A", "B", "C", "D"}:
            AnswerService.save_answer(current_session.id, answer.question_id, selected_option)

        if action == "prev":
            return redirect(url_for("exam.show_question", index=max(index - 1, 0)))

        if action == "finish":
            return redirect(url_for("exam.exam_result"))

        if index + 1 >= total_questions:
            return redirect(url_for("exam.finish_exam"))

        return redirect(url_for("exam.show_question", index=index + 1))

    progress = ExamNavigationService.progress(index, total_questions)
    answered_count = SessionService.get_answered_count(current_session.id)
    is_last_question = index == total_questions - 1

    return render_template(
        "exam/question.html",
        answer=answer,
        question=answer.question,
        progress=progress,
        is_last_question=is_last_question,
        answered_count=answered_count,
        total_questions=total_questions,
    )


@exam_bp.route("/exam/review")
def review_exam():
    return render_template("exam/review.html")


@exam_bp.route("/exam/finish")
def finish_exam():
    return render_template("exam/confirm_finish.html")


@exam_bp.route("/exam/result")
def exam_result():
    SessionService.finish_session()
    return render_template("exam/result.html")
