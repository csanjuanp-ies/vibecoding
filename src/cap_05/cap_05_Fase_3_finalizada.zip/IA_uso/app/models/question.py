from app.extensions import db


class Question(db.Model):
    __tablename__ = "questions"

    # La BBDD actual usa 'id' (TEXT) como identificador/codigo de pregunta.
    code = db.Column("id", db.String(50), primary_key=True)
    statement = db.Column("question", db.Text, nullable=False)
    option_a = db.Column("a", db.Text, nullable=False)
    option_b = db.Column("b", db.Text, nullable=False)
    option_c = db.Column("c", db.Text, nullable=False)
    option_d = db.Column("d", db.Text, nullable=False)
    correct_option = db.Column("correct_letter", db.String(1), nullable=False)

    # Columnas existentes en la tabla source, utiles para trazabilidad.
    correct_index = db.Column("correct", db.Integer, nullable=True)
    refs = db.Column(db.Text, nullable=True)
    figure = db.Column(db.Text, nullable=True)

    def options(self):
        return {
            "A": self.option_a,
            "B": self.option_b,
            "C": self.option_c,
            "D": self.option_d,
        }

