import json

from app.extensions import db
from app.models.question import Question
from app.repositories.question_repository import QuestionRepository


class QuestionBankService:
    @staticmethod
    def seed_from_json(file_path):
        with open(file_path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)

        created = 0
        for item in payload:
            exists = Question.query.filter_by(code=item["code"]).first()
            if exists:
                continue
            question = Question(
                code=item["code"],
                statement=item["statement"],
                option_a=item["options"]["A"],
                option_b=item["options"]["B"],
                option_c=item["options"]["C"],
                option_d=item["options"]["D"],
                correct_option=item["correct_option"],
            )
            db.session.add(question)
            created += 1

        db.session.commit()
        return created

    @staticmethod
    def get_questions_for_exam(limit):
        return QuestionRepository.first_n_questions(limit)

