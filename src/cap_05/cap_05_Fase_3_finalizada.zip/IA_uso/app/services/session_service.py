from datetime import datetime, timezone

from sqlalchemy import func
from sqlalchemy.orm import joinedload

from app.extensions import db
from app.models.answer import Answer
from app.models.exam_session import ExamSession
from app.models.question import Question


class SessionService:
    DEFAULT_TOTAL_QUESTIONS = 35
    ACTIVE_STATUS = "in_progress"
    FINISHED_STATUS = "finished"

    @staticmethod
    def get_active_session(total_questions=DEFAULT_TOTAL_QUESTIONS):
        session = (
            db.session.query(ExamSession)
            .filter_by(status=SessionService.ACTIVE_STATUS)
            .order_by(ExamSession.created_at.desc(), ExamSession.id.desc())
            .first()
        )

        if session is None:
            return SessionService.create_session(total_questions=total_questions)

        SessionService._ensure_answers_initialized(session)
        return session

    @staticmethod
    def create_session(total_questions=DEFAULT_TOTAL_QUESTIONS):
        session = ExamSession()
        session.status = SessionService.ACTIVE_STATUS
        session.total_questions = total_questions

        db.session.add(session)
        db.session.flush()

        question_codes = SessionService._pick_random_question_codes(total_questions)
        SessionService._bulk_create_answers(session.id, question_codes)

        db.session.commit()
        return session

    @staticmethod
    def get_or_create_active_session(total_questions=DEFAULT_TOTAL_QUESTIONS):
        return SessionService.get_active_session(total_questions=total_questions)

    @staticmethod
    def initialize_session(total_questions=DEFAULT_TOTAL_QUESTIONS):
        return SessionService.get_or_create_active_session(total_questions=total_questions)

    @staticmethod
    def get_session_question_codes(exam_session_id):
        rows = (
            db.session.query(Answer.question_id)
            .filter_by(exam_session_id=exam_session_id)
            .order_by(Answer.id.asc())
            .all()
        )
        return [question_id for (question_id,) in rows]

    @staticmethod
    def get_answer_by_index(exam_session_id, index):
        if index < 0:
            return None

        return (
            db.session.query(Answer)
            .options(joinedload(Answer.question))
            .filter_by(exam_session_id=exam_session_id)
            .order_by(Answer.id.asc())
            .offset(index)
            .limit(1)
            .first()
        )

    @staticmethod
    def get_answered_count(exam_session_id):
        return (
            db.session.query(Answer.id)
            .filter_by(exam_session_id=exam_session_id)
            .filter(Answer.selected_option.isnot(None))
            .count()
        )

    @staticmethod
    def finish_session(session_id=None):
        session = (
            db.session.get(ExamSession, session_id)
            if session_id is not None
            else SessionService.get_active_session()
        )

        if session is None or session.status == SessionService.FINISHED_STATUS:
            return session

        session.status = SessionService.FINISHED_STATUS
        session.finished_at = datetime.now(timezone.utc)
        db.session.commit()
        return session

    @staticmethod
    def _pick_random_question_codes(total_questions):
        rows = (
            db.session.query(Question.code)
            .order_by(func.random())
            .limit(total_questions)
            .all()
        )

        if len(rows) < total_questions:
            raise ValueError("No hay suficientes preguntas para crear la sesion")

        return [code for (code,) in rows]

    @staticmethod
    def _bulk_create_answers(exam_session_id, question_codes):
        answer_rows = [
            {"exam_session_id": exam_session_id, "question_id": code}
            for code in question_codes
        ]
        if answer_rows:
            db.session.bulk_insert_mappings(Answer, answer_rows)

    @staticmethod
    def _ensure_answers_initialized(session):
        answers_count = (
            db.session.query(Answer.id)
            .filter_by(exam_session_id=session.id)
            .count()
        )

        if answers_count > 0:
            return

        question_codes = SessionService._pick_random_question_codes(session.total_questions)
        SessionService._bulk_create_answers(session.id, question_codes)
        db.session.commit()


