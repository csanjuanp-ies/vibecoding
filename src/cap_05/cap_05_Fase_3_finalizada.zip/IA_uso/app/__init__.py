from flask import Flask
from pathlib import Path

from app.blueprints.exam import exam_bp
from app.config import Config
from app.extensions import db, migrate
from app.services.session_service import SessionService
from app.utils import run_initial_sql_migration_if_needed


def create_app(config_object=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object)

    # Control de la URI de BBDD por si existen algún error
    instance_path = Path(app.instance_path or app.root_path)
    instance_path.mkdir(parents=True, exist_ok=True)
    configured_uri = app.config.get("SQLALCHEMY_DATABASE_URI", "")
    is_relative_uri = (
        configured_uri.startswith("sqlite:///exam_app.db") or
        configured_uri == "sqlite:///exam_app.db"
    )
    if is_relative_uri:
        db_absolute_path = instance_path / "exam_app.db"
        app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{db_absolute_path.as_posix()}"

    db.init_app(app)
    migrate.init_app(app, db)

    app.register_blueprint(exam_bp)

    with app.app_context():
        run_initial_sql_migration_if_needed(app)
        db.create_all()
        exam_session = SessionService.initialize_session()
        app.config["CURRENT_EXAM_SESSION_ID"] = exam_session.id

    return app
