def test_start_route_shows_current_session_info(client):
    response = client.get("/")
    body = response.data.decode("utf-8")

    assert response.status_code == 200
    assert "Sesión actual" in body
    assert "Estado:" in body
    assert "Total de preguntas:" in body
    assert "Se muestran 35 claves primarias de preguntas disponibles." in body


