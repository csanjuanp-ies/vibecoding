from app.extensions import db
from app.models.answer import Answer
from app.services.answer_service import AnswerService
from app.services.session_service import SessionService


def test_question_route_shows_progress(client):
    response = client.get("/exam/question/0")
    body = response.data.decode("utf-8")

    assert response.status_code == 200
    assert "Pregunta 1 de 35" in body
    assert "Ir a la primera" in body
    assert "Ir a la última" in body
    assert "Revisar" not in body


def test_question_route_post_saves_answer_and_moves_next(app, client):
    with app.app_context():
        session = SessionService.get_active_session()
        first_question_code = SessionService.get_session_question_codes(session.id)[0]

    response = client.post(
        "/exam/question/0",
        data={"selected_option": "A", "action": "next"},
        follow_redirects=False,
    )

    assert response.status_code == 302
    assert "/exam/question/1" in response.headers["Location"]

    with app.app_context():
        answer = db.session.query(Answer).filter_by(
            exam_session_id=session.id,
            question_id=first_question_code,
        ).first()

        assert answer is not None
        assert answer.selected_option == "A"


def test_question_route_post_without_option_keeps_answer_unmodified_on_next(app, client):
    with app.app_context():
        session = SessionService.get_active_session()
        first_question_code = SessionService.get_session_question_codes(session.id)[0]

        initial_answer = db.session.query(Answer).filter_by(
            exam_session_id=session.id,
            question_id=first_question_code,
        ).first()
        assert initial_answer is not None
        assert initial_answer.selected_option is None

    response = client.post(
        "/exam/question/0",
        data={"action": "next"},
        follow_redirects=False,
    )

    assert response.status_code == 302
    assert "/exam/question/1" in response.headers["Location"]

    with app.app_context():
        answer_after = db.session.query(Answer).filter_by(
            exam_session_id=session.id,
            question_id=first_question_code,
        ).first()
        assert answer_after is not None
        assert answer_after.selected_option is None


def test_question_route_post_without_option_keeps_answer_unmodified_on_prev(app, client):
    with app.app_context():
        session = SessionService.get_active_session()
        second_question_code = SessionService.get_session_question_codes(session.id)[1]

        initial_answer = db.session.query(Answer).filter_by(
            exam_session_id=session.id,
            question_id=second_question_code,
        ).first()
        assert initial_answer is not None
        assert initial_answer.selected_option is None

    response = client.post(
        "/exam/question/1",
        data={"action": "prev"},
        follow_redirects=False,
    )

    assert response.status_code == 302
    assert "/exam/question/0" in response.headers["Location"]

    with app.app_context():
        answer_after = db.session.query(Answer).filter_by(
            exam_session_id=session.id,
            question_id=second_question_code,
        ).first()
        assert answer_after is not None
        assert answer_after.selected_option is None


def test_last_question_shows_finish_button_disabled_when_incomplete(app, client):
    response = client.get("/exam/question/34")
    body = response.data.decode("utf-8")

    assert response.status_code == 200
    assert "Finalizar examen" in body
    assert "disabled" in body


def test_finish_button_enabled_when_34_answered(app, client):
    with app.app_context():
        session = SessionService.get_active_session()
        question_codes = SessionService.get_session_question_codes(session.id)

        for idx, code in enumerate(question_codes[:34]):
            AnswerService.save_answer(session.id, code, chr(65 + (idx % 4)))

    response = client.get("/exam/question/34")
    body = response.data.decode("utf-8")

    assert response.status_code == 200
    assert "Finalizar examen" in body
    assert "disabled" not in body


def test_finish_button_not_shown_before_last_question(client):
    response = client.get("/exam/question/0")
    body = response.data.decode("utf-8")

    assert response.status_code == 200
    assert "Finalizar examen" not in body


def test_last_question_saves_on_finish_button(app, client):
    with app.app_context():
        session = SessionService.get_active_session()
        session_id = session.id
        question_codes = SessionService.get_session_question_codes(session_id)
        last_question_code = question_codes[-1]

        for idx, code in enumerate(question_codes[:34]):
            AnswerService.save_answer(session_id, code, chr(65 + (idx % 4)))

    response = client.post(
        "/exam/question/34",
        data={"selected_option": "B", "action": "finish"},
        follow_redirects=False,
    )

    assert response.status_code == 302
    assert "/exam/result" in response.headers["Location"]

    with app.app_context():
        answer = db.session.query(Answer).filter_by(
            exam_session_id=session_id,
            question_id=last_question_code,
        ).first()

        assert answer is not None
        assert answer.selected_option == "B"
