from app.repositories.question_repository import QuestionRepository


def test_first_n_questions_with_zero_returns_empty_list(app):
    with app.app_context():
        questions = QuestionRepository.first_n_questions(0)

    assert questions == []


def test_first_n_questions_with_one_returns_single_question(app):
    with app.app_context():
        questions = QuestionRepository.first_n_questions(1)

    assert len(questions) == 1
    assert isinstance(questions[0], str)
    assert questions[0]

