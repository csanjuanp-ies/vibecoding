"""
Test suite: Verificación de run_initial_sql_migration_if_needed

Cubre tres escenarios:
  1. La tabla questions NO existe  → se ejecuta la migración SQL y la crea.
  2. La tabla questions YA existe  → la función retorna sin ejecutar nada.
  3. El fichero de migración NO existe → lanza FileNotFoundError.

Ejecutar: python -m pytest tests/test_initial_migration.py -v
"""
import sqlite3
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
from flask import Flask

from app.config import TestingConfig
from app.extensions import db
from app.utils.migration import run_initial_sql_migration_if_needed, INITIAL_MIGRATION_FILE


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_app() -> Flask:
    """Crea una app Flask mínima con BD SQLite en memoria para tests."""
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(TestingConfig)
    db.init_app(app)
    return app


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def fresh_app():
    """App con BD en memoria vacía (sin ninguna tabla)."""
    app = _make_app()
    with app.app_context():
        yield app


@pytest.fixture
def migration_sql_path():
    """Ruta real al fichero de migración inicial."""
    return Path(__file__).parent.parent / "migrations" / INITIAL_MIGRATION_FILE


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestRunInitialMigrationIfNeeded:

    # ------------------------------------------------------------------
    # Escenario 1: tabla questions NO existe → se ejecuta la migración
    # ------------------------------------------------------------------

    def test_migration_creates_questions_table_when_absent(self, fresh_app, migration_sql_path):
        """Si no existe la tabla questions, se ejecuta el SQL y la crea."""
        with fresh_app.app_context():
            # Precondición: la tabla NO existe
            from sqlalchemy import inspect as sa_inspect
            assert not sa_inspect(db.engine).has_table("questions"), (
                "La BD en memoria debería estar vacía antes del test"
            )

            run_initial_sql_migration_if_needed(fresh_app)

            # Postcondición: la tabla existe y tiene datos
            assert sa_inspect(db.engine).has_table("questions"), (
                "La tabla questions debería existir tras la migración"
            )
            result = db.session.execute(
                db.text("SELECT COUNT(*) FROM questions")
            ).scalar()
            assert result > 0, "La migración debería haber insertado preguntas"

    def test_migration_populates_questions_with_expected_count(self, fresh_app, migration_sql_path):
        """La migración inicial carga las 423 preguntas del seed."""
        with fresh_app.app_context():
            run_initial_sql_migration_if_needed(fresh_app)

            count = db.session.execute(
                db.text("SELECT COUNT(*) FROM questions")
            ).scalar()
            assert count == 423, (
                f"Se esperaban 423 preguntas, se encontraron {count}"
            )

    def test_migration_creates_correct_schema(self, fresh_app):
        """La tabla questions creada tiene las columnas esperadas."""
        expected_columns = {"id", "correct", "question", "refs", "a", "b", "c", "d", "figure", "correct_letter"}

        with fresh_app.app_context():
            run_initial_sql_migration_if_needed(fresh_app)

            rows = db.session.execute(
                db.text("PRAGMA table_info(questions)")
            ).fetchall()
            created_columns = {row[1] for row in rows}

            assert expected_columns == created_columns, (
                f"Columnas inesperadas. Esperadas: {expected_columns}, "
                f"encontradas: {created_columns}"
            )

    # ------------------------------------------------------------------
    # Escenario 2: tabla questions YA existe → no se ejecuta nada
    # ------------------------------------------------------------------

    def test_migration_skipped_when_table_already_exists(self, fresh_app):
        """Si la tabla questions ya existe, la función retorna sin tocarla."""
        with fresh_app.app_context():
            # Creamos la tabla manualmente con un dato centinela
            db.session.execute(db.text(
                "CREATE TABLE questions "
                "(id TEXT PRIMARY KEY, correct INTEGER, question TEXT, "
                "refs TEXT, a TEXT, b TEXT, c TEXT, d TEXT, figure TEXT, correct_letter TEXT)"
            ))
            db.session.execute(db.text(
                "INSERT INTO questions VALUES ('SENTINEL', 0, 'q', NULL, 'a','b','c','d', NULL, 'A')"
            ))
            db.session.commit()

            # La función NO debería borrar ni recrear la tabla
            run_initial_sql_migration_if_needed(fresh_app)

            count = db.session.execute(
                db.text("SELECT COUNT(*) FROM questions")
            ).scalar()
            assert count == 1, (
                "Con la tabla ya existente, la función no debe modificar los datos"
            )

    def test_migration_does_not_call_executescript_when_table_exists(self, fresh_app):
        """Verifica que executescript nunca se invoca si la tabla ya existe."""
        with fresh_app.app_context():
            # Crear tabla mínima para que has_table() devuelva True
            db.session.execute(db.text(
                "CREATE TABLE questions "
                "(id TEXT PRIMARY KEY, correct INTEGER, question TEXT, "
                "refs TEXT, a TEXT, b TEXT, c TEXT, d TEXT, figure TEXT, correct_letter TEXT)"
            ))
            db.session.commit()

            mock_inspector = MagicMock()
            mock_inspector.has_table.return_value = True

            with patch("app.utils.migration.inspect", return_value=mock_inspector), \
                 patch("app.utils.migration.db") as mock_db:
                mock_db.engine = MagicMock()

                run_initial_sql_migration_if_needed(fresh_app)

                mock_db.engine.begin.assert_not_called()

    # ------------------------------------------------------------------
    # Escenario 3: fichero de migración NO existe → FileNotFoundError
    # ------------------------------------------------------------------

    def test_migration_raises_if_sql_file_missing(self, fresh_app):
        """Lanza FileNotFoundError cuando el fichero SQL de migración no existe."""
        with fresh_app.app_context():
            with patch("app.utils.migration.INITIAL_MIGRATION_FILE", "fichero_inexistente.sql"):
                with pytest.raises(FileNotFoundError) as exc_info:
                    run_initial_sql_migration_if_needed(fresh_app)

            assert "fichero_inexistente.sql" in str(exc_info.value)

    def test_migration_error_message_contains_path(self, fresh_app):
        """El mensaje de FileNotFoundError incluye la ruta esperada."""
        missing_name = "no_existe.sql"
        with fresh_app.app_context():
            with patch("app.utils.migration.INITIAL_MIGRATION_FILE", missing_name):
                with pytest.raises(FileNotFoundError) as exc_info:
                    run_initial_sql_migration_if_needed(fresh_app)

        error_msg = str(exc_info.value)
        assert missing_name in error_msg, (
            f"El mensaje de error debería contener '{missing_name}'. "
            f"Mensaje recibido: {error_msg}"
        )



