import pytest

from app import create_app
from app.config import TestingConfig, Config


@pytest.fixture
def app():
    """Fixture: Aplicación con BD en memoria (para testing aislado)."""
    application = create_app(TestingConfig)
    return application


@pytest.fixture
def client(app):
    """Fixture: Cliente HTTP para testing de rutas."""
    return app.test_client()


@pytest.fixture
def app_production():
    """Fixture: Aplicación con BD producción (instance/exam_app.db)."""
    application = create_app(Config)
    return application


@pytest.fixture
def client_production(app_production):
    """Fixture: Cliente HTTP para testing con BD producción."""
    return app_production.test_client()

