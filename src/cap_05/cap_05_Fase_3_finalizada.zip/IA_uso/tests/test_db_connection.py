"""
Test suite: Validación de conexión SQLite y accesibilidad de datos.
Ejecutar: pytest tests/test_db_connection.py -v

Verifica que:
1. La URI SQLite está correctamente configurada
2. La aplicación puede conectar a instance/exam_app.db
3. Los datos de preguntas están accesibles
4. El ORM (SQLAlchemy) funciona correctamente
"""
import pytest
from pathlib import Path

from app import create_app
from app.config import Config
from app.models.question import Question


class TestDatabaseConnection:
    """Tests de configuración y conectividad a SQLite."""

    def test_app_creation_with_production_config(self):
        """La aplicación se crea correctamente con Config (producción)."""
        app = create_app(Config)
        assert app is not None
        assert app.config["SQLALCHEMY_DATABASE_URI"].startswith("sqlite:///")

    def test_sqlite_uri_format_is_valid(self):
        """La URI SQLite tiene formato válido para rutas absolutas."""
        app = create_app(Config)
        uri = app.config["SQLALCHEMY_DATABASE_URI"]

        # Debe ser sqlite:/// seguido de ruta
        assert uri.startswith("sqlite:///")

        # Debe contener 'exam_app.db'
        assert "exam_app.db" in uri

    def test_instance_path_exists(self):
        """La carpeta instance se crea automáticamente."""
        app = create_app(Config)
        instance_path = Path(app.instance_path)

        assert instance_path.exists()
        assert instance_path.is_dir()

    def test_database_file_exists(self):
        """El archivo exam_app.db existe en instance/."""
        app = create_app(Config)
        db_path = Path(app.instance_path) / "exam_app.db"

        assert db_path.exists()
        assert db_path.is_file()
        assert db_path.stat().st_size > 0

    def test_database_uri_matches_instance_path(self):
        """La URI SQLite apunta a instance/exam_app.db."""
        app = create_app(Config)

        instance_path = Path(app.instance_path)
        db_path = instance_path / "exam_app.db"
        uri = Path(app.config["SQLALCHEMY_DATABASE_URI"][-len(str(db_path)):]).as_posix()

        # La URI debe contener la ruta absoluta con forward slashes
        expected_path = db_path.as_posix()
        assert expected_path in uri


class TestDatabaseConnectivity:
    """Tests de conectividad y acceso a datos."""

    def test_app_context_connection(self, app_production):
        """Puede ejecutarse código dentro de app context."""
        with app_production.app_context():
            # Si no lanza excepción, la conexión está OK
            question = Question.query.first()
            assert question is not None

    def test_questions_table_has_data(self, app_production):
        """La tabla questions contiene datos (423 registros esperados)."""
        with app_production.app_context():
            count = Question.query.count()
            assert count > 0
            assert count == 423  # Validación específica con datos conocidos

    def test_first_question_properties(self, app_production):
        """El primer registro tiene las propiedades esperadas."""
        with app_production.app_context():
            question = Question.query.first()

            # Validar propiedades del modelo
            assert hasattr(question, 'code')
            assert hasattr(question, 'statement')
            assert hasattr(question, 'correct_option')
            assert hasattr(question, 'option_a')
            assert hasattr(question, 'option_b')
            assert hasattr(question, 'option_c')
            assert hasattr(question, 'option_d')

    def test_question_data_integrity(self, app_production):
        """Los datos de las preguntas tienen valores válidos."""
        with app_production.app_context():
            question = Question.query.filter_by(code='G1A01').first()

            assert question is not None
            assert question.code == 'G1A01'
            assert len(question.statement) > 0
            assert question.correct_option in ['A', 'B', 'C', 'D']
            assert len(question.option_a) > 0
            assert len(question.option_b) > 0
            assert len(question.option_c) > 0
            assert len(question.option_d) > 0

    def test_question_options_method(self, app_production):
        """El método options() devuelve dict correctamente."""
        with app_production.app_context():
            question = Question.query.first()
            options = question.options()

            assert isinstance(options, dict)
            assert set(options.keys()) == {'A', 'B', 'C', 'D'}
            assert all(isinstance(v, str) and len(v) > 0 for v in options.values())

    def test_query_by_code_works(self, app_production):
        """Las búsquedas por code funcionan correctamente."""
        with app_production.app_context():
            codes_to_test = ['G1A01', 'G1A02', 'G1A03']

            for code in codes_to_test:
                question = Question.query.filter_by(code=code).first()
                assert question is not None
                assert question.code == code


class TestDatabaseModels:
    """Tests de acceso a modelos relacionados."""

    def test_can_import_all_models(self):
        """Todos los modelos se importan sin errores."""
        from app.models.question import Question
        from app.models.exam_session import ExamSession
        from app.models.answer import Answer

        assert Question is not None
        assert ExamSession is not None
        assert Answer is not None

    def test_question_model_has_correct_tablename(self):
        """El modelo Question usa la tabla 'questions'."""
        assert Question.__tablename__ == 'questions'

    def test_question_model_primary_key_is_code(self):
        """La clave primaria de Question es 'code'."""
        from sqlalchemy import inspect

        mapper = inspect(Question)
        pk_columns = [c.name for c in mapper.primary_key]

        assert 'id' in pk_columns or 'code' in pk_columns


class TestDatabaseSchema:
    """Tests de validación del esquema SQLite."""

    def test_questions_table_schema(self, app_production):
        """Valida que la tabla questions tiene las columnas esperadas."""
        import sqlite3
        
        db_path = Path(app_production.instance_path) / "exam_app.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("PRAGMA table_info(questions)")
        columns = {row[1]: row[2] for row in cursor.fetchall()}
        
        expected_columns = {
            'id': 'TEXT',
            'correct': 'INTEGER',
            'question': 'TEXT',
            'refs': 'TEXT',
            'a': 'TEXT',
            'b': 'TEXT',
            'c': 'TEXT',
            'd': 'TEXT',
            'figure': 'TEXT',
            'correct_letter': 'TEXT',
        }
        
        for col, dtype in expected_columns.items():
            assert col in columns, f"Columna '{col}' no encontrada en tabla questions"
        
        conn.close()


# ============================================================================
# Script ejecutable para diagnóstico manual (sin pytest)
# ============================================================================
#
# if __name__ == "__main__":
#     """Ejecutar directamente: python -m tests.test_db_connection"""
#
#     print("\n" + "="*70)
#     print("DIAGNOSTICO DE CONEXION SQLite (Ejecutable)")
#     print("="*70)
#
#     try:
#         app = create_app(Config)
#         print("\n✓ APLICACION CREADA EXITOSAMENTE")
#         print(f"  URI SQLite: {app.config['SQLALCHEMY_DATABASE_URI']}")
#         print(f"  Instance path: {app.instance_path}")
#
#         with app.app_context():
#             q_count = Question.query.count()
#             print(f"\n✓ CONECTIVIDAD OK")
#             print(f"  Total preguntas en BD: {q_count}")
#
#             first_q = Question.query.first()
#             print(f"\n✓ DATOS ACCESIBLES")
#             print(f"  Código: {first_q.code}")
#             print(f"  Enunciado: {first_q.statement[:60]}...")
#             print(f"  Respuesta correcta: {first_q.correct_option}")
#             print(f"  Opciones: A={first_q.option_a[:30]}..., B={first_q.option_b[:30]}...")
#
#     except Exception as e:
#         print(f"\n✗ ERROR: {type(e).__name__}")
#         print(f"  {str(e)[:150]}")
#         import traceback
#         traceback.print_exc()
#
#     finally:
#         print("\n" + "="*70 + "\n")
#
