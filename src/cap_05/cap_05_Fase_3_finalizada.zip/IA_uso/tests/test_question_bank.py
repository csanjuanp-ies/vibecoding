import csv
from pathlib import Path


def test_seed_file_has_minimum_schema():
    seed_path = Path("data/questions_seed_dw.csv")
    with seed_path.open(encoding="utf-8", newline="") as seed_file:
        payload = list(csv.DictReader(seed_file))

    assert isinstance(payload, list)
    assert len(payload) >= 1
    first = payload[0]
    assert {
        "id",
        "correct",
        "refs",
        "question",
        "a",
        "b",
        "c",
        "d",
        "figure",
        "correct_letter",
    }.issubset(first.keys())

