from app.services.question_bank_service import QuestionBankService


def test_get_questions_for_exam_with_zero_returns_empty_list(app):
    with app.app_context():
        questions = QuestionBankService.get_questions_for_exam(0)

    assert questions == []


def test_get_questions_for_exam_with_one_returns_single_question(app):
    with app.app_context():
        questions = QuestionBankService.get_questions_for_exam(1)

    assert len(questions) == 1
    assert isinstance(questions[0], str)
    assert questions[0]

