from app.extensions import db
from app.models.answer import Answer
from app.models.exam_session import ExamSession
from app.services.session_service import SessionService


def test_app_initializes_active_exam_session(app):
    with app.app_context():
        active_sessions = db.session.query(ExamSession).filter_by(status=SessionService.ACTIVE_STATUS).all()

        assert len(active_sessions) == 1
        assert app.config["CURRENT_EXAM_SESSION_ID"] == active_sessions[0].id

        answers_count = (
            db.session.query(Answer.id)
            .filter_by(exam_session_id=active_sessions[0].id)
            .count()
        )
        assert answers_count == active_sessions[0].total_questions


def test_initialize_session_reuses_existing_active_session(app):
    with app.app_context():
        first_session = SessionService.initialize_session()
        second_session = SessionService.initialize_session()

        assert first_session.id == second_session.id
        assert db.session.query(ExamSession).filter_by(status=SessionService.ACTIVE_STATUS).count() == 1

        answers_count = db.session.query(Answer.id).filter_by(exam_session_id=first_session.id).count()
        assert answers_count == first_session.total_questions


def test_get_session_question_codes_returns_total_questions(app):
    with app.app_context():
        session = SessionService.initialize_session()
        question_codes = SessionService.get_session_question_codes(session.id)

        assert len(question_codes) == session.total_questions
        assert len(set(question_codes)) == session.total_questions


def test_finish_session_marks_session_as_finished(app):
    with app.app_context():
        session = SessionService.initialize_session()
        finished_session = SessionService.finish_session(session.id)

        assert finished_session is not None
        assert finished_session.status == SessionService.FINISHED_STATUS
        assert finished_session.finished_at is not None
        assert db.session.query(ExamSession).filter_by(status=SessionService.ACTIVE_STATUS).count() == 0


