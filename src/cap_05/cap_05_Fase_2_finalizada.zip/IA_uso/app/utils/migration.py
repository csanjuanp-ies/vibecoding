"""
Utilidades de migración de base de datos.

Proporciona la lógica de migración inicial SQL que se ejecuta
al arranque de la aplicación si la BD aún no está inicializada.
"""
from pathlib import Path

from sqlalchemy import inspect

from app.extensions import db


INITIAL_MIGRATION_FILE = "001_initial_from_instance.sql"


def run_initial_sql_migration_if_needed(app):
    """Ejecuta la migración SQL inicial solo si la tabla 'questions' no existe.

    Args:
        app: Instancia Flask con contexto de aplicación activo.

    Raises:
        FileNotFoundError: Si el fichero SQL de migración no se encuentra.
    """
    migration_path = Path(app.root_path).parent / "migrations" / INITIAL_MIGRATION_FILE

    if inspect(db.engine).has_table("questions"):
        return

    if not migration_path.exists():
        raise FileNotFoundError(
            f"No se encontro la migracion inicial: {migration_path}"
        )

    migration_sql = migration_path.read_text(encoding="utf-8")

    with db.engine.begin() as connection:
        # El fichero contiene multiples sentencias SQL y transacción explicita.
        raw_connection = connection.connection
        raw_connection.executescript(migration_sql)

