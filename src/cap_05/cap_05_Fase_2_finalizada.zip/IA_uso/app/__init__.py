from flask import Flask
from pathlib import Path

from app.blueprints.exam import exam_bp
from app.config import Config
from app.extensions import db, migrate
from app.utils import run_initial_sql_migration_if_needed


def create_app(config_object=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object)

    # Control de la URI de BBDD por si existen algún error
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    configured_uri = app.config.get("SQLALCHEMY_DATABASE_URI", "")
    is_relative_uri = (
        configured_uri.startswith("sqlite:///exam_app.db") or
        configured_uri == "sqlite:///exam_app.db"
    )
    if is_relative_uri:
        db_absolute_path = Path(app.instance_path) / "exam_app.db"
        app.config["SQLALCHEMY_DATABASE_URI"] = r"sqlite:////" + str(db_absolute_path).replace('\\', '\\\\')

    db.init_app(app)
    migrate.init_app(app, db)

    app.register_blueprint(exam_bp)

    with app.app_context():
        run_initial_sql_migration_if_needed(app)
        db.create_all()

    return app
