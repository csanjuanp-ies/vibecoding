from flask import render_template, request

from app.blueprints.exam import exam_bp
from app.services.question_bank_service import QuestionBankService


@exam_bp.route("/")
def start_exam():
    count = request.args.get("count", default=10, type=int)
    questions = QuestionBankService.get_questions_for_exam(count)
    return render_template("exam/start.html", questions=questions, len_questions=len(questions))


@exam_bp.route("/exam/question/<int:index>")
def show_question(index):
    return render_template("exam/question.html", index=index)


@exam_bp.route("/exam/review")
def review_exam():
    return render_template("exam/review.html")


@exam_bp.route("/exam/finish")
def finish_exam():
    return render_template("exam/confirm_finish.html")


@exam_bp.route("/exam/result")
def exam_result():
    return render_template("exam/result.html")

