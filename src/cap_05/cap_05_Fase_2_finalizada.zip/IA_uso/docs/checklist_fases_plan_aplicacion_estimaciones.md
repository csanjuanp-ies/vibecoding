# Checklist de fases con tiempos estimados

Version extendida del checklist basada en `estructura_y_plan_flask.md`, con estimaciones para:
- Perfil Junior: 2 anos de experiencia
- Perfil Senior: 4 anos de experiencia

> Supuestos de estimacion
> - Proyecto en stack Flask conocido por ambos perfiles.
> - Jornada efectiva: 6 horas productivas por dia.
> - Incluye desarrollo + pruebas + ajustes basicos.
> - No incluye esperas externas largas (aprobaciones, infraestructura, cambios de alcance grandes).

## Resumen por fase (tiempo total)
Las columnas de tiempos de Junio y Senior son estimaciones basadas en experiencia previa y complejidad de cada fase. 
La columna de Real (IA) se completará con los tiempos reales registrados durante el desarrollo.

| Fase | Junior (2 años) | Senior (4 años) |   Real (IA) |
|---|----------------:|----------------:|------------:|
| Fase 1 - Base tecnica |        2-3 dias |        1-2 dias |  10 minutos |
| Fase 2 - Banco de preguntas |        2-4 dias |        1-2 dias |     3 horas |
| Fase 3 - Flujo de examen |        5-8 dias |        3-5 dias |   --Falta-- |
| Fase 4 - Cierre y evaluacion |        2-4 dias |        1-2 dias |   --Falta-- |
| Fase 5 - Calidad |        3-5 dias |        2-3 dias |   --Falta-- |
| **Total estimado** |  **14-24 dias** |   **8-14 dias** |   --Falta-- |

## Fase 1 - Base tecnica

- [x] Crear `app factory` en `app/__init__.py`.
  - Junior: 4-6 h
  - Senior: 2-4 h
- [x] Configurar extensiones en `app/extensions.py` (`SQLAlchemy`, `Flask-Migrate`, `Flask-WTF`).
  - Junior: 4-8 h
  - Senior: 2-4 h
- [x] Definir modelos iniciales (`Question`, `ExamSession`, `Answer`).
  - Junior: 8-12 h
  - Senior: 4-6 h

**Subtotal Fase 1**
- Junior: 16-26 h (2-3 dias)
- Senior: 8-14 h (1-2 dias)

## Fase 2 - Banco de preguntas (RF-01)

- [x] Implementar carga inicial desde `data/questions_seed_dw.csv`.
  - Junior: 4-6 h
  - Senior: 2-3 h
- [x] Agregar CRUD basico del banco. Seleccion de preguntas para examen.
  - Junior: 8-14 h
  - Senior: 4-8 h
- [x] Validar unicidad de identificador y formato de opciones.
  - Junior: 4-8 h
  - Senior: 2-4 h

**Subtotal Fase 2**
- Junior: 16-28 h (2-4 dias)
- Senior: 8-15 h (1-2 dias)

## Fase 3 - Flujo de examen (RF-02, RF-03, RF-04, RF-05)

- [ ] Generar sesion de 35 preguntas aleatorias sin repeticion.
  - Junior: 6-10 h
  - Senior: 3-6 h
- [ ] Mostrar una pregunta por vista con progreso (`n/35`).
  - Junior: 6-10 h
  - Senior: 3-5 h
- [ ] Guardar respuesta seleccionada y permitir edicion.
  - Junior: 8-12 h
  - Senior: 4-8 h
- [ ] Implementar navegacion completa (avanzar, retroceder, saltar, estado).
  - Junior: 10-16 h
  - Senior: 6-10 h

**Subtotal Fase 3**
- Junior: 30-48 h (5-8 dias)
- Senior: 16-29 h (3-5 dias)

## Fase 4 - Cierre y evaluacion (RF-06, RF-07, RF-08)

- [ ] Pantalla de confirmacion final con conteo de no respondidas.
  - Junior: 4-8 h
  - Senior: 2-4 h
- [ ] Bloquear cambios tras confirmar envio.
  - Junior: 3-6 h
  - Senior: 2-4 h
- [ ] Calcular aciertos, errores y porcentaje.
  - Junior: 4-8 h
  - Senior: 2-4 h
- [ ] Mostrar resultados (resumen + detalle opcional).
  - Junior: 4-8 h
  - Senior: 2-4 h

**Subtotal Fase 4**
- Junior: 15-30 h (2-4 dias)
- Senior: 8-16 h (1-2 dias)

## Fase 5 - Calidad

- [ ] Tests unitarios de servicios (`generation`, `grading`, `navigation`).
  - Junior: 10-16 h
  - Senior: 6-10 h
- [ ] Tests de integracion de rutas principales.
  - Junior: 6-12 h
  - Senior: 4-8 h
- [ ] Casos borde: menos de 35 preguntas, sesion inválida, doble envío.
  - Junior: 4-8 h
  - Senior: 2-5 h

**Subtotal Fase 5**
- Junior: 20-36 h (3-5 dias)
- Senior: 12-23 h (2-3 dias)

## Seguimiento global

- [x] Fase 1 completada. Se ha completado completamente con IA en 10 minutos en el momento 
de crear el esqueleto del proyecto.
- [x] Fase 2 completada. Se ha completado completamente con IA en 3 horas, incluyendo ajustes y validaciones.
- [ ] Fase 3 completada
- [ ] Fase 4 completada
- [ ] Fase 5 completada


## Margen recomendado

- [ ] Agregar 15-25% de margen por incertidumbre tecnica y cambios de alcance.
- [ ] Revisar estimaciones al cierre de cada fase con tiempos reales.

